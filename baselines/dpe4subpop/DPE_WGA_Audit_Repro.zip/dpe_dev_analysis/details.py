import numpy as np,pandas as pd
from sklearn.metrics import roc_auc_score,average_precision_score
from statsmodels.stats.proportion import proportion_confint
root='/mnt/data/dpe_dev_analysis/development_bundle'
rows=[]
for s in range(3):
 for split in ['meta_train','meta_select']:
  a=np.load(f'{root}/seed{s}/{split}.npz'); ps=a['probs'][:,:,1]; pp=ps.mean(1); y=a['y'];g=a['group']; 
  cp=(ps>=.5)==y[:,None];pred=(pp>=.5); basec=pred==y
  vwrong=cp.sum(1)
  for gr in range(4):
   mask=g==gr; n=mask.sum(); incorrect=np.sum(mask&~basec); canfix=np.sum(mask&~basec&(vwrong>0)); majcorrect=np.sum(mask&~basec&(vwrong>=8)); allwrong=np.sum(mask&(vwrong==0)); rate=np.mean(basec[mask]);lo,hi=proportion_confint(int(np.sum(basec[mask])),int(n),alpha=.05,method='wilson')
   rows.append(dict(seed=s,split=split,group=gr,n=n,correct=int(np.sum(basec[mask])),errors=incorrect,recoverable=canfix,majority_correct_but_wrong=majcorrect,all_experts_wrong=allwrong,acc=rate,CI_low=lo,CI_high=hi,mean_member_correct=np.mean(vwrong[mask]),avg_margin=np.mean(np.abs(pp[mask]-.5))))
print(pd.DataFrame(rows).to_string(index=False,float_format=lambda x:f'{x:.4f}'))
pd.DataFrame(rows).to_csv('/mnt/data/dpe_dev_analysis/group_headroom.csv',index=False)
