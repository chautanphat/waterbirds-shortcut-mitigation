import numpy as np,pandas as pd
from scipy.optimize import minimize
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.model_selection import StratifiedKFold
root='/mnt/data/dpe_dev_analysis/development_bundle'
rows=[]
for s in range(3):
 a=np.load(f'{root}/seed{s}/meta_train.npz');b=np.load(f'{root}/seed{s}/meta_select.npz')
 p=np.vstack((a['probs'][:,:,1],b['probs'][:,:,1])); y=np.hstack((a['y'],b['y'])); g=np.hstack((a['group'],b['group'])); z=np.vstack((a['embedding'],b['embedding'])).astype('float32'); ids=np.hstack((a['sample_id'],b['sample_id']))
 assert len(set(ids.tolist()))==1199
 preds={name:np.zeros(len(y)) for name in ['uniform','pseudo_cap025','pseudo_cap03']}
 kf=StratifiedKFold(n_splits=5,shuffle=True,random_state=3001)
 for fold,(t,v) in enumerate(kf.split(p,y)):
  zp=PCA(n_components=24,random_state=0,svd_solver='randomized').fit_transform(z[t])
  cg=KMeans(n_clusters=2,random_state=1,n_init=6).fit_predict(zp)
  masks=[cg==j for j in (0,1)]
  preds['uniform'][v]=p[v].mean(axis=1)
  for cap,name in [(0.25,'pseudo_cap025'),(0.3,'pseudo_cap03')]:
   def objective(w):
    pr=np.clip(p[t]@w,1e-8,1-1e-8)
    L=-y[t]*np.log(pr)-(1-y[t])*np.log(1-pr)
    return max(L[mask].mean() for mask in masks)+0.02*np.sum((w-1/15)**2)
   opt=minimize(objective,np.ones(15)/15,bounds=[(0,cap)]*15,constraints={'type':'eq','fun':lambda w:w.sum()-1},method='SLSQP',options={'maxiter':100,'ftol':1e-8})
   if not opt.success: print('opt_fail',s,fold,cap,opt.message)
   w=opt.x if opt.success else np.ones(15)/15
   preds[name][v]=p[v]@w
 np.savez_compressed(f'/mnt/data/dpe_dev_analysis/cv_preds_seed{s}.npz',sample_id=ids,y=y,group=g,**preds)
 for name,q in preds.items():
  cor=(q>=.5)==y
  gg=[cor[g==j].mean() for j in range(4)];cc=[cor[y==j].mean() for j in (0,1)]
  rows.append(dict(seed=s,method=name,AA=cor.mean(),BA=np.mean(cc),WCA=min(cc),WGA=min(gg),**{f'g{j}':gg[j] for j in range(4)},n_flips=int(np.sum((q>=.5)!=(p.mean(1)>=.5))),corr=int(np.sum(cor&~((p.mean(1)>=.5)==y))),broken=int(np.sum(~cor&((p.mean(1)>=.5)==y)))))
D=pd.DataFrame(rows);D.to_csv('/mnt/data/dpe_dev_analysis/cv_sensitivity_results.csv',index=False)
print(D.round(5).to_string(index=False))
print('\nMEAN\n',D.groupby('method')[['AA','BA','WCA','WGA','g0','g1','g2','g3']].mean().round(5).to_string())
