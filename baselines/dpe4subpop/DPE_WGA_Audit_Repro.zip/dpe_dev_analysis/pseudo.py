import numpy as np,pandas as pd
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from scipy.optimize import minimize
root='/mnt/data/dpe_dev_analysis/development_bundle'; rows=[]

def evaluate(ps,y,g,seed,name,split,w):
 p=ps@w
 c=(p>=.5)==y; groups=[c[g==j].mean() for j in range(4)]
 rows.append(dict(method=name,seed=seed,split=split,AA=c.mean(),BA=np.mean([c[y==j].mean() for j in range(2)]),WGA=min(groups),g0=groups[0],g1=groups[1],g2=groups[2],g3=groups[3],max_weight=w.max(),Neff=1/np.sum(w**2)))

for s in range(3):
 a=np.load(f'{root}/seed{s}/meta_train.npz'); b=np.load(f'{root}/seed{s}/meta_select.npz')
 tr=a['probs'][:,:,1];va=b['probs'][:,:,1]; y=a['y']; g=a['group']; yv=b['y'];gv=b['group'];
 X=a['embedding'].astype('float32'); XV=b['embedding'].astype('float32')
 # prefit PCA with train only, group-blind
 z=PCA(n_components=24,random_state=0,svd_solver='randomized').fit_transform(X)
 zV=None
 pseudo={}
 for K in [2,4,6,8]:
  km=KMeans(n_clusters=K,n_init=6,random_state=1).fit(z)
  pseudo[f'global_K{K}']=km.labels_
 # conditional class Kmeans 2,4
 for K in [2,4]:
  labels=np.zeros(len(y),dtype=int)
  for cls in [0,1]:
   ids=y==cls
   lab=KMeans(n_clusters=K,n_init=5,random_state=1).fit_predict(z[ids]);labels[ids]=lab+cls*K
  pseudo[f'withinclass_K{K}']=labels
 evaluate(va,yv,gv,s,'uniform','select',np.ones(15)/15)
 for key,cl in pseudo.items():
  cid=y.astype(int)*0+cl
  allmask=[cid==v for v in np.unique(cid) if sum(cid==v)>=20]
  for objective in ['group_avg','group_max','group_soft','group_tail']:
   for lam in [.02,.10,.3]:
    def loss_w(w):
     p=np.clip(tr@w,1e-7,1-1e-7)
     ell=-y*np.log(p)-(1-y)*np.log(1-p)
     gl=np.array([ell[mask].mean() for mask in allmask]);
     if objective=='group_avg': val=np.mean(gl)
     elif objective=='group_max':val=max(gl)
     elif objective=='group_soft':val=np.logaddexp.reduce(40*gl)/40
     else:val=np.mean([np.sort(ell[mask])[-max(1,int(.3*sum(mask))):].mean() for mask in allmask])
     return val+lam*((w-1/15)**2).sum()
    res=minimize(loss_w,np.ones(15)/15,bounds=[(0,.35)]*15,constraints={'type':'eq','fun':lambda w:w.sum()-1},method='SLSQP',options={'maxiter':100,'ftol':1e-7})
    w=res.x if res.success else np.ones(15)/15
    name=key+'_'+objective+'_r'+str(lam)
    evaluate(tr,y,g,s,name,'train',w)
    evaluate(va,yv,gv,s,name,'select',w)
P=pd.DataFrame(rows);P.to_csv('/mnt/data/dpe_dev_analysis/pseudo_results.csv',index=False)
S=P[P.split=='select'].groupby('method')[['AA','WGA','BA','max_weight']].agg(['mean','std'])
S.columns=['_'.join(x) for x in S.columns]
print(S.sort_values(['WGA_mean','AA_mean'],ascending=False).head(35).round(4).to_string())
print('uniform',S.loc['uniform'].round(4))
