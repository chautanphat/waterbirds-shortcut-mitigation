import numpy as np
sdata=[np.load(f'/mnt/data/dpe_dev_analysis/cv_preds_seed{s}.npz') for s in range(3)]
ref=sdata[0]
ids=ref['sample_id']; y=ref['y'];g=ref['group'];n=len(y)
D=[]
for a in sdata:
 ix={k:i for i,k in enumerate(a['sample_id'])}
 order=np.array([ix[k] for k in ids]);assert np.all(a['y'][order]==y);assert np.all(a['group'][order]==g)
 D.append({name:(a[name][order]>=.5)==y for name in ['uniform','pseudo_cap025','pseudo_cap03']})
rng=np.random.default_rng(77)
per_group=[np.where(g==j)[0] for j in range(4)]
B=4000; dif=np.zeros((B,2))
for b in range(B):
 index=np.hstack([rng.choice(idx,len(idx),replace=True) for idx in per_group])
 for c,name in enumerate(['pseudo_cap025','pseudo_cap03']):
  df=[]
  for seed in range(3):
   u=D[seed]['uniform'];v=D[seed][name]
   df.append(min(v[index][g[index]==j].mean() for j in range(4))-min(u[index][g[index]==j].mean() for j in range(4)))
  dif[b,c]=np.mean(df)
for j,name in enumerate(['pseudo_cap025','pseudo_cap03']):
 print(name,'wga_delta_pp avg', round(dif[:,j].mean()*100,3),'95% stratified paired bootstrap', np.round(np.quantile(dif[:,j],[.025,.5,.975])*100,3),'P(delta>0)',round((dif[:,j]>0).mean(),3))
# AA conditional bootstrap shared seeds
A=np.zeros((B,2))
for b in range(B):
 index=rng.choice(np.arange(n),n,replace=True)
 for c,name in enumerate(['pseudo_cap025','pseudo_cap03']):
  A[b,c]=np.mean([D[seed][name][index].mean()-D[seed]['uniform'][index].mean() for seed in range(3)])
for j,name in enumerate(['pseudo_cap025','pseudo_cap03']):
 print(name,'aa_delta pp CI', np.round(np.quantile(A[:,j],[.025,.5,.975])*100,3))
