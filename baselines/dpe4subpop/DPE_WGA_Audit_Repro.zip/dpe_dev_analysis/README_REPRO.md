# DPE WGA research audit reproducibility

Input data is NOT included. Extract `development_oof_bundle.zip` such that `development_bundle/seed*/meta_train.npz` and `meta_select.npz` are placed alongside the scripts in `dpe_dev_analysis/development_bundle/`.

Run from the directory containing the scripts, using NumPy, Pandas, SciPy, scikit-learn and statsmodels:

```bash
python details.py
python bench.py
python pseudo.py
python robust_static.py
python cluster_gate.py
python cluster_probe.py
python cv_sensitivity.py
python bootstrap.py
```

The scripts output CSVs in `/mnt/data/dpe_dev_analysis` as executed in this workspace. If running elsewhere, replace hard-coded paths. This bundle includes the exact output CSVs. No historical test set was accessed. Some grids are exploratory, not pre-registered confirmatory validation.
