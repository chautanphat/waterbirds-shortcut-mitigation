import numpy as np,pandas as pd
from scipy.optimize import minimize
from sklearn.metrics import roc_auc_score
root='/mnt/data/dpe_dev_analysis/development_bundle'
rows=[]; curves=[]

def calc(p,y,g,method,seed,split,threshold=.5,extra={}):
 pr=(p>=threshold).astype(int); cor=(pr==y); gg=[cor[g==i].mean() for i in range(4)]; cc=[cor[y==i].mean() for i in range(2)]
 rows.append(dict(method=method,seed=seed,split=split,accuracy=cor.mean(),ba=np.mean(cc),wca=min(cc),wga=min(gg),g0=gg[0],g1=gg[1],g2=gg[2],g3=gg[3],threshold=threshold,**extra))

for s in range(3):
 dtr=np.load(f'{root}/seed{s}/meta_train.npz'); ds=np.load(f'{root}/seed{s}/meta_select.npz'); tr=dtr['probs'][:,:,1]; va=ds['probs'][:,:,1]
 y=dtr['y']; yv=ds['y']; g=dtr['group']; gv=ds['group'];
 u=tr.mean(1); uv=va.mean(1)
 for fn in ['mean','median','trimmed2','trimmed4','vote','huber_mean']:
  if fn=='mean': p0,pv=u,uv
  elif fn=='median': p0,pv=np.median(tr,axis=1),np.median(va,axis=1)
  elif fn=='trimmed2': p0,pv=np.mean(np.sort(tr,axis=1)[:,2:-2],axis=1),np.mean(np.sort(va,axis=1)[:,2:-2],axis=1)
  elif fn=='trimmed4': p0,pv=np.mean(np.sort(tr,axis=1)[:,4:-4],axis=1),np.mean(np.sort(va,axis=1)[:,4:-4],axis=1)
  elif fn=='vote': p0,pv=np.mean(tr>.5,axis=1),np.mean(va>.5,axis=1)
  else:
   def robust(p):
    med=np.median(p,axis=1,keepdims=True); mad=np.median(abs(p-med),axis=1,keepdims=True)+1e-6
    weights=np.minimum(1, 1.5*mad/(abs(p-med)+1e-8))
    return (p*weights).sum(1)/weights.sum(1)
   p0,pv=robust(tr),robust(va)
  calc(p0,y,g,fn,s,'train');calc(pv,yv,gv,fn,s,'select')
 # threshold optim from train for multiple objectives
 thresholds=np.linspace(.455,.55,1001)
 for objective in ['AA','BA','WCA','WCA_AA1pp','WCA_AA0.5pp','AA_WCA95','WCA_AA0pp','balanced_CE_logits','AA_WCA94']:
  trainAA=((u>=.5)==y).mean()
  try:
   auc=[]
   for t in thresholds:
    pred=u>=t; ca=(pred==y); aa=ca.mean(); rr=np.array([ca[y==c].mean() for c in (0,1)]); ba=rr.mean(); wc=rr.min()
    if objective=='AA': score=aa;valid=True
    elif objective=='BA':score=ba;valid=True
    elif objective=='WCA':score=wc;valid=True
    elif objective=='WCA_AA1pp':score=wc;valid=aa>=trainAA-.01-1e-9
    elif objective=='WCA_AA0.5pp':score=wc;valid=aa>=trainAA-.005-1e-9
    elif objective=='WCA_AA0pp':score=wc;valid=aa>=trainAA-1e-9
    elif objective=='AA_WCA95':score=aa;valid=wc>=.95
    elif objective=='AA_WCA94':score=aa;valid=wc>=.94
    elif objective=='balanced_CE_logits':score=ba;valid=True
    if valid: auc.append((score,aa,-abs(t-.5),t))
   t=max(auc)[-1]
   calc(u,y,g,'thr_'+objective,s,'train',t)
   calc(uv,yv,gv,'thr_'+objective,s,'select',t)
  except ValueError: pass
 # fixed threshold shifts, no optimization but check diagnostic
 for t in [.485,.49,.495,.5,.505,.51,.515]:
  calc(uv,yv,gv,'fixed_thr_'+str(t),s,'select',t)
 # regression combination constrained deterministic using train
 # learn static weight w with optimization CE, BalancedCE, max class CE, tail class CE
 for obj in ['ce','bce','tail','max_ce']:
  for strength in [0.01,0.1,1.0]:
   for f in [0,1]:
    pass
   def loss_w(w):
    ps=np.clip(tr@w,1e-5,1-1e-5)
    loss=-y*np.log(ps)-(1-y)*np.log(1-ps)
    cls=np.array([loss[y==j].mean() for j in (0,1)])
    if obj=='ce': ls=loss.mean()
    elif obj=='bce':ls=cls.mean()
    elif obj=='max_ce':ls=np.log(np.exp(20*cls).sum())/20
    else:ls=np.mean([np.mean(np.sort(loss[y==j])[-max(1,int(.2*sum(y==j))):]) for j in (0,1)])
    # quadratic scaled
    return ls+strength*np.sum((w-1/15)**2)
   res=minimize(loss_w,np.ones(15)/15,bounds=[(0,1)]*15,constraints={'type':'eq','fun':lambda w:w.sum()-1},method='SLSQP', options={'maxiter':100,'ftol':1e-8})
   w=res.x/res.x.sum() if res.success else np.ones(15)/15
   method=f'static_{obj}_ridge{strength}'
   calc(tr@w,y,g,method,s,'train',extra={'weight_max':w.max()});calc(va@w,yv,gv,method,s,'select',extra={'weight_max':w.max()})
# write
result=pd.DataFrame(rows);result.to_csv('/mnt/data/dpe_dev_analysis/bench_results.csv',index=False)
for split in ['train','select']:
 d=result[result.split==split]; av=d.groupby('method')[['accuracy','ba','wca','wga','g0','g1','g2','g3']].mean().sort_values(['wga','accuracy'],ascending=False)
 print('\n',split, '\n',av.to_string(float_format=lambda x:f'{x*100:.2f}'))
print('\nSEED threshold best:')
print(result[(result.split=='select') & result.method.str.contains('thr_')][['seed','method','threshold','accuracy','ba','wga','g0','g1','g2','g3']].to_string(index=False))
