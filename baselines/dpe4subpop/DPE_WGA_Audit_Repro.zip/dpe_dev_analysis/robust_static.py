import numpy as np,pandas as pd
from scipy.optimize import minimize
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
root='/mnt/data/dpe_dev_analysis/development_bundle'
rows=[]
for s in range(3):
 a=np.load(f'{root}/seed{s}/meta_train.npz'); b=np.load(f'{root}/seed{s}/meta_select.npz'); tr=a['probs'][:,:,1]; va=b['probs'][:,:,1]; y=a['y']; yv=b['y']; g=b['group'];
 z=PCA(n_components=24,random_state=0,svd_solver='randomized').fit_transform(a['embedding'].astype('float32'))
 clusters=KMeans(n_clusters=2,n_init=6,random_state=1).fit_predict(z)
 for kind in ['class_max','global_k2_max']:
  masks=[y==i for i in range(2)] if kind=='class_max' else [clusters==i for i in range(2)]
  for cap in [.10,.15,.20,.25,.30,.35,1.]:
   for ridge in [.01,.02,.05,.1]:
    def loss(w):
     pp=np.clip(tr@w,1e-8,1-1e-8); el=-y*np.log(pp)-(1-y)*np.log(1-pp)
     return np.max([el[mask].mean() for mask in masks])+ridge*((w-1/15)**2).sum()
    res=minimize(loss,np.ones(15)/15,bounds=[(0,cap)]*15,constraints={'type':'eq','fun':lambda w:w.sum()-1},method='SLSQP',options={'maxiter':100,'ftol':1e-8})
    if not res.success:continue
    for alpha in [0.25,0.5,0.75,1.0]:
     w=alpha*res.x+(1-alpha)/15
     p=va@w;correct=(p>=.5)==yv
     group=[correct[g==i].mean() for i in range(4)]
     rows.append(dict(seed=s,kind=kind,cap=cap,ridge=ridge,alpha=alpha,AA=correct.mean(),WGA=min(group),BA=np.mean([correct[yv==v].mean() for v in (0,1)]),maxw=w.max(),g0=group[0],g1=group[1],g2=group[2],g3=group[3]))
D=pd.DataFrame(rows); D.to_csv('/mnt/data/dpe_dev_analysis/robust_static_results.csv',index=False)
for kind in ['class_max','global_k2_max']:
 tmp=D[D.kind==kind].groupby(['cap','ridge','alpha'])[['AA','WGA','BA','maxw']].mean().reset_index()
 tmp=tmp.sort_values(['WGA','AA'],ascending=False)
 print('\n',kind,'TOP WGA\n',tmp.head(20).round(4).to_string(index=False))
 print('average top combined >=AA baseline (.95)\n',tmp[tmp.AA>=.95].head(12).round(4).to_string(index=False))
