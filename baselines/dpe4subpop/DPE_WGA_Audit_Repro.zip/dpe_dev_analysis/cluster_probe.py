import numpy as np
from sklearn.preprocessing import StandardScaler,normalize
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, adjusted_mutual_info_score
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score
root='/mnt/data/dpe_dev_analysis/development_bundle'
for s in [0,1,2]:
 a=np.load(f'{root}/seed{s}/meta_train.npz');b=np.load(f'{root}/seed{s}/meta_select.npz')
 X=a['embedding'].astype(np.float32);XV=b['embedding'].astype(np.float32)
 y=a['y'];yv=b['y'];g=a['group'];gv=b['group']; bg=g%2;bgv=gv%2
 for transform in ['pca_raw','pca_norm','pca_whiten']:
  if transform=='pca_norm': x=normalize(X);xv=normalize(XV)
  else: x=X;xv=XV
  pca=PCA(n_components=24,random_state=0,svd_solver='randomized',whiten=(transform=='pca_whiten'))
  Z=pca.fit_transform(x);ZV=pca.transform(xv)
  print('seed',s,transform,'PCA explained',round(pca.explained_variance_ratio_.sum(),3))
  for k in [2,4,8,16]:
   km=KMeans(n_clusters=k,random_state=0,n_init=5,max_iter=150).fit(Z)
   c=km.predict(ZV)
   print('k',k,'ARI bg',round(adjusted_rand_score(bgv,c),3),'NMI bg',round(adjusted_mutual_info_score(bgv,c),3),'NMI group',round(adjusted_mutual_info_score(gv,c),3),'cluster min',min(np.bincount(c)))
  # Diagnostic only group-supervised probe (NOT for modeling group-blind)
  clf=LogisticRegression(C=.05,max_iter=200).fit(Z,bg)
  pred=clf.predict(ZV)
  print('grp_sup_probe_BA',round(balanced_accuracy_score(bgv,pred),3),'class',round(np.mean(pred==bgv),3))
  for c in [0,1]:
   z=Z[y==c]; zb=ZV[yv==c]
   km=KMeans(n_clusters=2,random_state=0,n_init=10).fit(z)
   lab=km.predict(zb); truth=bgv[yv==c]
   print('class',c,'cluster2 bgARI',round(adjusted_rand_score(truth,lab),3),'purity',round(max(np.mean(lab==truth),np.mean(lab!=truth)),3))
  if s!=0:break
