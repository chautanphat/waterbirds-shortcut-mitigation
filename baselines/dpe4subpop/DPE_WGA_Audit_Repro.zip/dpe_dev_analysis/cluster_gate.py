import numpy as np,pandas as pd
from scipy.optimize import minimize
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
root='/mnt/data/dpe_dev_analysis/development_bundle'; rows=[]
for s in range(3):
 a=np.load(f'{root}/seed{s}/meta_train.npz');b=np.load(f'{root}/seed{s}/meta_select.npz')
 tr=a['probs'][:,:,1];va=b['probs'][:,:,1]; y=a['y'];yv=b['y']; g=b['group']
 pca=PCA(n_components=24,random_state=0,svd_solver='randomized').fit(a['embedding'].astype('float32'))
 z=pca.transform(a['embedding'].astype('float32'));zv=pca.transform(b['embedding'].astype('float32'))
 for k in [2,4]:
  km=KMeans(n_clusters=k,random_state=1,n_init=5).fit(z)
  c=km.predict(z);cv=km.predict(zv)
  for obj in ['ce','balanced_ce','worst_class']:
   for reg in [.05,.2,.5]:
    weights=np.ones((k,15))/15
    for cl in range(k):
     mask=c==cl
     if mask.sum()<30:continue
     pp=tr[mask]; yy=y[mask]
     def loss(w):
      ppred=np.clip(pp@w,1e-7,1-1e-7)
      ell=-yy*np.log(ppred)-(1-yy)*np.log(1-ppred)
      if obj=='ce':val=ell.mean()
      elif obj=='balanced_ce':val=np.mean([ell[yy==i].mean() for i in [0,1] if (yy==i).sum()>=5])
      else:val=max([ell[yy==i].mean() for i in [0,1] if (yy==i).sum()>=5])
      return val+reg*np.sum((w-1/15)**2)
     opt=minimize(loss,np.ones(15)/15,method='SLSQP',bounds=[(0,.2)]*15,constraints={'type':'eq','fun':lambda w:w.sum()-1},options={'maxiter':100,'ftol':1e-8})
     if opt.success:weights[cl]=opt.x
    for alpha in [.25,.5,1.]:
     pw=(1-alpha)/15 + alpha*weights[cv,:]
     pr=(va*pw).sum(axis=1)>=.5
     co=pr==yv;arr=[co[g==j].mean() for j in range(4)]
     rows.append(dict(method=f'K{k}_{obj}_r{reg}_a{alpha}',seed=s,AA=co.mean(),BA=np.mean([co[yv==i].mean() for i in (0,1)]),WGA=min(arr),g0=arr[0],g1=arr[1],g2=arr[2],g3=arr[3],max_w=np.max(pw)))
D=pd.DataFrame(rows);D.to_csv('/mnt/data/dpe_dev_analysis/cluster_gate_results.csv',index=False)
print(D.groupby('method')[['AA','BA','WGA','max_w']].mean().sort_values(['WGA','AA'],ascending=False).head(27).round(4).to_string())
