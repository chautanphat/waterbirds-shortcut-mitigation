"""Project-owned method implementations."""
